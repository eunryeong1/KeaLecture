import './App.css';
// import Car from './Car';
// import Header from './Header';
import Garage from './Garage';

function App() {
  return (
    <div>
      <Garage/>
      {/* <Car/> */}
      {/* <Header/> */}
    </div>
  );
}

export default App;
